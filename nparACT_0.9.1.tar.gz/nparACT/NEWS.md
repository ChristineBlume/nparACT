The nparACT package
================

<!-- NEWS.md is generated from NEWS.Rmd. Please edit that file -->

## News

### nparACT 0.9.1 (2025-15-12)

#### Changes

- Exported package functions to ensure correct namespace behaviour when
  installing from CRAN.

#### Bug fixes

- Fixed an error where package functions were not exported, which could
  lead to errors when calling high-level functions.

### nparACT 0.9.0 (2025-22-09)

First NEWS update. All changes will be documented in this file from now
on. Fixed unknown issues that led to removal from CRAN earlier this
year. Roxygen was now used to build the package and potential issues
with running the worked example have been solved.
